# fittingtools
Some tools built upon scipy's least squares fitting.
