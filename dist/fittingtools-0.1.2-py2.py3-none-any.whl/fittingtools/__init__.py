"""
Basic tools to generate confidence intervals and prediction confidence
intervals based on `scipy.optimize.least_squares`
"""
__version__ = "0.1.2"
__author__ = 'Erick Martinez Loran'
